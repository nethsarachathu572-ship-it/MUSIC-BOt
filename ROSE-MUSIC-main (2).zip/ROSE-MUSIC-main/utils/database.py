import aiosqlite
import os
import time


class Database:
    def __init__(self):
        self.path = os.getenv("DATABASE_PATH", "rose.db")

    async def init(self):
        async with aiosqlite.connect(self.path) as db:
            await db.execute("""
                CREATE TABLE IF NOT EXISTS guilds (
                    guild_id INTEGER PRIMARY KEY,
                    prefix TEXT DEFAULT '>',
                    twentyfourseven INTEGER DEFAULT 0
                )
            """)
            await db.execute("""
                CREATE TABLE IF NOT EXISTS liked_songs (
                    user_id INTEGER,
                    track_title TEXT,
                    track_author TEXT,
                    track_uri TEXT,
                    added_at INTEGER
                )
            """)
            await db.execute("""
                CREATE TABLE IF NOT EXISTS noprefix (
                    user_id    INTEGER PRIMARY KEY,
                    added_by   INTEGER NOT NULL,
                    added_at   INTEGER NOT NULL,
                    expires_at INTEGER
                )
            """)
            await db.commit()

    # ── Prefix Methods ───────────────────────────────────────────

    async def get_prefix(self, guild_id):
        async with aiosqlite.connect(self.path) as db:
            cur = await db.execute("SELECT prefix FROM guilds WHERE guild_id = ?", (guild_id,))
            row = await cur.fetchone()
            return row[0] if row else None

    async def set_prefix(self, guild_id, prefix):
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                "INSERT INTO guilds (guild_id, prefix) VALUES (?, ?) "
                "ON CONFLICT(guild_id) DO UPDATE SET prefix = ?",
                (guild_id, prefix, prefix)
            )
            await db.commit()

    # ── 24/7 Methods ─────────────────────────────────────────────

    async def get_247(self, guild_id):
        async with aiosqlite.connect(self.path) as db:
            cur = await db.execute("SELECT twentyfourseven FROM guilds WHERE guild_id = ?", (guild_id,))
            row = await cur.fetchone()
            return bool(row[0]) if row else False

    async def set_247(self, guild_id, value):
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                "INSERT INTO guilds (guild_id, twentyfourseven) VALUES (?, ?) "
                "ON CONFLICT(guild_id) DO UPDATE SET twentyfourseven = ?",
                (guild_id, int(value), int(value))
            )
            await db.commit()

    # ── Liked Songs Methods ──────────────────────────────────────

    async def like_song(self, user_id, title, author, uri):
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                "INSERT INTO liked_songs VALUES (?, ?, ?, ?, ?)",
                (user_id, title, author, uri, int(time.time()))
            )
            await db.commit()

    async def unlike_song(self, user_id, uri):
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                "DELETE FROM liked_songs WHERE user_id = ? AND track_uri = ?",
                (user_id, uri)
            )
            await db.commit()

    async def is_liked(self, user_id, uri):
        async with aiosqlite.connect(self.path) as db:
            cur = await db.execute(
                "SELECT 1 FROM liked_songs WHERE user_id = ? AND track_uri = ?",
                (user_id, uri)
            )
            return await cur.fetchone() is not None

    async def get_liked(self, user_id):
        async with aiosqlite.connect(self.path) as db:
            cur = await db.execute(
                "SELECT * FROM liked_songs WHERE user_id = ? ORDER BY added_at DESC",
                (user_id,)
            )
            return await cur.fetchall()

    # ── NoPrefix Methods ─────────────────────────────────────────

    async def add_noprefix(self, user_id: int, added_by: int, expires_at: int = None):
        """Grant noprefix to a user."""
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                """
                INSERT INTO noprefix (user_id, added_by, added_at, expires_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(user_id) DO UPDATE SET
                    added_by = excluded.added_by,
                    added_at = excluded.added_at,
                    expires_at = excluded.expires_at
                """,
                (user_id, added_by, int(time.time()), expires_at),
            )
            await db.commit()

    async def remove_noprefix(self, user_id: int) -> bool:
        """Remove noprefix from a user. Returns True if it existed."""
        async with aiosqlite.connect(self.path) as db:
            cursor = await db.execute(
                "DELETE FROM noprefix WHERE user_id = ?", (user_id,)
            )
            await db.commit()
            return cursor.rowcount > 0

    async def is_noprefix(self, user_id: int) -> bool:
        """Check whether a user has active (non-expired) noprefix."""
        async with aiosqlite.connect(self.path) as db:
            cur = await db.execute(
                "SELECT expires_at FROM noprefix WHERE user_id = ?", (user_id,)
            )
            row = await cur.fetchone()
            if not row:
                return False
            expires_at = row[0]
            if expires_at is not None and expires_at < int(time.time()):
                # expired, clean it up
                await db.execute(
                    "DELETE FROM noprefix WHERE user_id = ?", (user_id,)
                )
                await db.commit()
                return False
            return True

    async def get_noprefix(self, user_id: int):
        """Return a user's noprefix info as a tuple, or None."""
        async with aiosqlite.connect(self.path) as db:
            cur = await db.execute(
                "SELECT user_id, added_by, added_at, expires_at FROM noprefix WHERE user_id = ?",
                (user_id,),
            )
            return await cur.fetchone()

    async def list_noprefix(self):
        """Return the list of all noprefix users."""
        async with aiosqlite.connect(self.path) as db:
            cur = await db.execute(
                "SELECT user_id, added_by, added_at, expires_at FROM noprefix"
            )
            return await cur.fetchall()